"""A video player class."""

from .video_library import VideoLibrary
import random
import pandas


class VideoPlayer:
    """A class used to represent a Video Player."""

    def __init__(self):
        self.paused = False
        self.currently_playing = ...
        self._video_library = VideoLibrary()
        self.playlist = pandas.Series([],
                                      index=[])

    def number_of_videos(self):
        num_videos = len(self._video_library.get_all_videos())
        print(f"{num_videos} videos in the library")

    def show_all_videos(self):
        """Returns all videos."""

        titles = pandas.Series(
            ["Funny Dogs", "Amazing Cats", "Another Cat Video", "Life at Google", "Video about nothing"],
            index=[2, 0, 1, 3, 4])
        titles.sort_index()
        video_id = pandas.Series(["funny_dogs_video_id", "amazing_cats_video_id", "another_cat_video_id",
                                  "life_at_google_video_id", "nothing_video_id"],
                                 index=[2, 0, 1, 3, 4])
        video_id.sort_index()
        tags = pandas.Series(
            [('#dog', '#animal'), ('#cat', '#animal'), ('#cat', '#animal'), ('#google', '#career'), ''],
            index=[2, 0, 1, 3, 4])
        tags.sort_index()
        print("Here's a list of all available videos:")

        for i in range(0, len(titles)):
            title = titles[i]
            vid = video_id[i]
            tag = tags[i]
            tagst = " ".join(tag)
            print(f"{title} ({vid}) [{tagst}]")

    def play_video(self, video_id):
        """Plays the respective video.

        Args:
            video_id: The video_id to be played.
        """
        name = self._video_library.get_video(video_id)

        if not name:
            print("Cannot play video: Video does not exist")
        elif self.currently_playing is not ...:
            self.stop_video()
            print(f"Playing video: {name.title}")
            self.currently_playing = name.title
            self.paused = False
        else:
            print(f"Playing video: {name.title}")
            self.currently_playing = name.title
            self.paused = False

    def stop_video(self):
        """Stops the current video."""
        if self.currently_playing is not ...:
            print(f"Stopping video: {self.currently_playing}")
            self.currently_playing = ...
            self.paused = False
        else:
            print("Cannot stop video: No video is currently playing")

    def play_random_video(self):
        """Plays a random video from the video library."""
        video_id = ["funny_dogs_video_id", "amazing_cats_video_id", "another_cat_video_id",
                    "life_at_google_video_id", "nothing_video_id"]
        random_video = self._video_library.get_video(video_id[random.randint(0, len(video_id) - 1)])

        if random_video is None:
            print("Cannot play video: Video does not exist")
            if not self.paused:
                print(f"Still playing: {self.currently_playing}")
            elif self.paused:
                print(f"{self.currently_playing} is still paused!")
        elif self.currently_playing is not ...:
            self.stop_video()
            print(f"Playing video: {random_video.title}")
            self.currently_playing = random_video.title
            self.paused = False
        else:
            print(f"Playing video: {random_video.title}")
            self.currently_playing = random_video.title
            self.paused = False

    def pause_video(self):
        """Pauses the current video."""

        if not self.paused and self.currently_playing is not ...:
            print(f"Pausing video: {self.currently_playing}")
            self.paused = True
        elif self.paused:
            print(f"Video already paused: {self.currently_playing}")

        if self.currently_playing is ...:
            print("Cannot pause video: No video is currently playing")

    def continue_video(self):
        """Resumes playing the current video."""

        if not self.paused and self.currently_playing is not ...:
            print("Cannot continue video: Video is not paused")
        elif self.paused:
            print(f"Continuing video: {self.currently_playing}")
            self.paused = False
        elif self.currently_playing is ...:
            print("Cannot continue video: No video is currently playing")

    def show_playing(self):
        """Displays video currently playing."""
        titles = ["Funny Dogs", "Amazing Cats", "Another Cat Video", "Life at Google", "Video about nothing"]
        video_id = ["funny_dogs_video_id", "amazing_cats_video_id", "another_cat_video_id",
                    "life_at_google_video_id", "nothing_video_id"]
        tags = [('#dog', '#animal'), ('#cat', '#animal'), ('#cat', '#animal'), ('#google', '#career'), '']

        if self.currently_playing is ...:
            print("No video is currently playing")

        for i in range(0, len(titles)):
            if self.currently_playing == titles[i]:
                title = titles[i]
                vid = video_id[i]
                tag = tags[i]
                tagst = " ".join(tag)
                if self.currently_playing is not ...:
                    if not self.paused:
                        print(f"Currently playing: {title} ({vid})"
                              f" [{tagst}]")
                        break
                    elif self.paused:
                        print(f"Currently playing: {title} ({vid})"
                              f" [{tagst}] - PAUSED")
                        break

    def create_playlist(self, playlist_name):
        """Creates a playlist with a given name.

        Args:
            playlist_name: The playlist name.
        """

        if playlist_name not in self.playlist[i]:

            print(f"Successfully created new playlist: {playlist_name}")
            self.playlist.append(playlist_name)
        elif playlist_name in self.playlist.index:
            print("Cannot create playlist: A playlist with the same name already exists")


        # for i in range(0, len(self.playlist)):
        #     if playlist_name not in self.playlist[i]:
        #         print(f"Successfully created new playlist: {playlist_name}")
        #         self.playlist.append(playlist_name)
        #         self.playlist.index[i] = i
        #         break
        #     elif playlist_name in self.playlist.index:
        #         print("Cannot create playlist: A playlist with the same name already exists")
        #         break

    def add_to_playlist(self, playlist_name, video_id):
        """Adds a video to a playlist with a given name.

        Args:
            playlist_name: The playlist name.
            video_id: The video_id to be added.
        """
        # name = self._video_library.get_video(video_id)
        # for i in self.playlist:
        #     i = 0
        #     if video_id not in playlist_name:
        #         print(f"Added video to {playlist_name}: {name.title}")
        #         self.playlist.index(playlist_name, video_id)
        #     elif video_id in self.playlist[playlist_name]:
        #         print(f"Cannot add video to {playlist_name}: Video already added")
        #     elif video_id not in name.video_id:
        #         print(f"Cannot add video to {playlist_name}: Video does not exist")
        #     elif playlist_name not in self.playlist:
        #         print(f"Cannot add video to {playlist_name}: Playlist does not exist")
        #     elif video_id not in name.video_id and playlist_name not in self.playlist:
        #         print(f"Cannot add video to {playlist_name}: Playlist does not exist")
        #         print(f"Cannot add video to {playlist_name}: Video does not exist")

    def show_all_playlists(self):
        """Display all playlists."""

        print("show_all_playlists needs implementation")

    def show_playlist(self, playlist_name):
        """Display all videos in a playlist with a given name.

        Args:
            playlist_name: The playlist name.
        """
        print("show_playlist needs implementation")

    def remove_from_playlist(self, playlist_name, video_id):
        """Removes a video to a playlist with a given name.

        Args:
            playlist_name: The playlist name.
            video_id: The video_id to be removed.
        """
        print("remove_from_playlist needs implementation")

    def clear_playlist(self, playlist_name):
        """Removes all videos from a playlist with a given name.

        Args:
            playlist_name: The playlist name.
        """
        print("clears_playlist needs implementation")

    def delete_playlist(self, playlist_name):
        """Deletes a playlist with a given name.

        Args:
            playlist_name: The playlist name.
        """
        print("deletes_playlist needs implementation")

    def search_videos(self, search_term):
        """Display all the videos whose titles contain the search_term.

        Args:
            search_term: The query to be used in search.
        """
        print("search_videos needs implementation")

    def search_videos_tag(self, video_tag):
        """Display all videos whose tags contains the provided tag.

        Args:
            video_tag: The video tag to be used in search.
        """
        print("search_videos_tag needs implementation")

    def flag_video(self, video_id, flag_reason=""):
        """Mark a video as flagged.

        Args:
            video_id: The video_id to be flagged.
            flag_reason: Reason for flagging the video.
        """
        print("flag_video needs implementation")

    def allow_video(self, video_id):
        """Removes a flag from a video.

        Args:
            video_id: The video_id to be allowed again.
        """
        print("allow_video needs implementation")
